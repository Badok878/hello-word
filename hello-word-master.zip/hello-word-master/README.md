1. # hello-word

2.

3.Hi Humans!

4.

5.Hubot here, I Like Node,js and Coffeescript (that's what I'm made of!).
  
6.I've had tacos on the moon and find them far superior to Earth tacos.
 
7.
